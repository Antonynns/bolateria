<?php
    session_start();
    $_SESSION['idUsuarioLogado']=$lista[0]->getId;
    header("Location: index.php");
?>